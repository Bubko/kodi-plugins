# Kodi video plugin to LIVE TV SK-CZ

Kodi Plugin that lets you watch almost all channels from Slovakia and Czech Republic LIVE TV SK-CZ

# Prerequisites
- Kodi Version 17.0+

# Installation
Download the latest version.
In Kodi, navigate to Add-ons > Add-on browser > Install from zip file. help
Browse for the downloaded zip file and click OK.

# Compatibility

This Plugin Requires Kodi Version 17.0+

# Disclaimer
Feel free to report any issues with the plugin, though I don't guarantee that requests will be heard in prompt time.