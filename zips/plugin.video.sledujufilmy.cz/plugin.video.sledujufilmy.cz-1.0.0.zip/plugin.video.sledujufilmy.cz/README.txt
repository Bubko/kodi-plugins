# Kodi video plugin to sledujufilmy.cz

Kodi Plugin that lets you watch almost all movies HD and for free from sledujufilmy.cz.

# Prerequisites
- Kodi Version 17.0+
- [script.module.urlresolver](https://github.com/tvaddonsco/script.module.urlresolver)
- [BeautifulSoup](https://www.crummy.com/software/BeautifulSoup/bs4/doc/#)

# Installation
Download the latest version.
In Kodi, navigate to Add-ons > Add-on browser > Install from zip file. help
Browse for the downloaded zip file and click OK.

# Compatibility

This Plugin Requires Kodi Version 17.0+

# Disclaimer
Feel free to report any issues with the plugin, though I don't guarantee that requests will be heard in prompt time.